import { socketManager } from './SocketManager';
import { stateSync } from '@core/state/synchronization/StateSync';
import { logger } from '../logger/Logger';
import { ProductionRecoveryEngine } from '../production/recovery/ProductionRecoveryEngine';

export enum MqttState {
  IDLE = 'IDLE',
  CONNECTING = 'CONNECTING',
  CONNECTED = 'CONNECTED',
  DEGRADED = 'DEGRADED',
  RECONNECTING = 'RECONNECTING',
  FAILED = 'FAILED'
}

class MqttManager {
  private static instance: MqttManager;
  private state: MqttState = MqttState.IDLE;
  private initialized = false;

  private constructor() {}

  public static getInstance(): MqttManager {
    if (!MqttManager.instance) {
      MqttManager.instance = new MqttManager();
    }
    return MqttManager.instance;
  }

  private reconnectCooldown = 2000;
  private maxCooldown = 30000;
  private lastReconnectAttempt = 0;

  public connect() {
    if (this.initialized) return;

    const now = Date.now();
    if (now - this.lastReconnectAttempt < this.reconnectCooldown) {
      return; // Wait for the scheduled retry
    }

    this.lastReconnectAttempt = now;
    logger.info('MQTT', 'Bridge sequence initiated...');
    
    const socket = socketManager.getSocket();
    if (!socket) {
      // Exponential backoff for recovery
      this.reconnectCooldown = Math.min(this.reconnectCooldown * 1.5, this.maxCooldown);
      logger.warn('MQTT', `Socket unavailable. Backing off: ${Math.round(this.reconnectCooldown)}ms`);
      setTimeout(() => this.connect(), this.reconnectCooldown);
      return;
    }

    this.setupListeners(socket);
    this.initialized = true;
    this.reconnectCooldown = 2000; // Reset on success
  }

  private setupListeners(socket: any) {
    socket.on('mqtt:status', (data: { connected: boolean }) => {
      const newState = data.connected ? MqttState.CONNECTED : MqttState.DEGRADED;
      
      if (this.state !== newState) {
        this.state = newState;
        // Calm Log: Only log state changes with high importance
        logger.info('MQTT', `Infrastructure_Link_State: ${this.state}`);
        this.syncHealth(data.connected);
      }

      // Adaptive Health reporting: 30s pulse instead of 15s for Calm Mode
      if (data.connected) {
        this.throttledPing();
      }
    });

    socket.on('mqtt:message', ({ topic, payload }: { topic: string, payload: string }) => {
      // Trace-only reporting for data packets to keep log clean
      logger.trace('MQTT', `Payload_Ingress: ${topic}`);
      stateSync.trackEvent();
    });
  }

  private lastPingTime = 0;
  private throttledPing() {
    const now = Date.now();
    if (now - this.lastPingTime > 30000) {
      ProductionRecoveryEngine.ping('MQTT_LAYER');
      this.lastPingTime = now;
    }
  }

  private syncHealth(connected: boolean) {
    stateSync.updateMqttHealth({
      connected,
      mqttMode: 'REALTIME',
      mqttRecoveryState: this.state as any,
      reconnectAttempts: 0,
      circuitBreakerState: 'CLOSED'
    });
  }

  public publish(topic: string, message: any) {
    const socket = socketManager.getSocket();
    if (socket) {
      const msg = typeof message === 'string' ? message : JSON.stringify(message);
      socket.emit('mqtt:publish', { topic, message: msg });
    }
  }

  public disconnect() {
    // Backend handles real disconnect
    this.state = MqttState.IDLE;
    this.syncHealth(false);
  }

  public getState() {
    return this.state;
  }
}

export const mqttManager = MqttManager.getInstance();
