import { defineConfig } from 'vite';
import react from '@vitejs/plugin-react';
import path from 'path';

export default defineConfig({
  plugins: [react()],
  resolve: {
    alias: {
      '@': path.resolve(__dirname, './client'),
      '@modules': path.resolve(__dirname, './modules'),
      '@shared': path.resolve(__dirname, './shared'),
      '@ui': path.resolve(__dirname, './ui'),
      '@lib': path.resolve(__dirname, './client/lib'),
      '@client': path.resolve(__dirname, './client'),
      '@core': path.resolve(__dirname, './client/core'),
    },
  },
  server: {
    port: 3000,
    hmr: false,
  },
});
