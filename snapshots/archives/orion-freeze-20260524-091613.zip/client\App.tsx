import React, { useEffect, useState } from 'react';
import { useLocation } from 'react-router-dom';
import { useSystemStore } from '@core/state/stores/useSystemStore';
import { moduleRegistry } from '@core/modules/registry/ModuleRegistry';
import { registerAllModules } from '@core/modules/registry/registerModules';
import { runtimeManager } from '@core/runtime/RuntimeManager';
import { moduleHealthMonitor } from '@core/modules/health/ModuleHealthMonitor';
import { routerManager } from '@core/router/RouterManager';
import { NavigationEngine } from '@core/router/NavigationEngine';
import { OrionShell } from './OrionShell';

export default function App() {
  const setCurrentView = useSystemStore(state => state.setCurrentView);
  const location = useLocation();
  const [isReady, setIsReady] = useState(false);

  useEffect(() => {
    const boot = async () => {
      // 1. Module Registration
      registerAllModules();
      
      // 2. Router Bootstrap (Syncs routes from modules)
      await routerManager.bootstrap();

      // 3. Runtime Bootstrap
      await runtimeManager.bootstrap();

      // 4. Initialize Registered Modules
      await moduleRegistry.initializeAll();
      
      setIsReady(true);
      moduleHealthMonitor.start();
    };

    boot();

    return () => {
      // Cleanup
    };
  }, []);

  // Sync currentView store and persist route
  useEffect(() => {
    const activeMod = moduleRegistry.getAllModules().find(m => m.route === location.pathname);
    if (activeMod) {
      setCurrentView(activeMod.id);
      routerManager.persistRoute(location.pathname);
    }
  }, [location.pathname, setCurrentView]);

  if (!isReady) {
    return (
      <div className="fixed inset-0 bg-[#050505] flex items-center justify-center">
        <div className="flex flex-col items-center gap-4">
          <div className="w-12 h-12 border-2 border-primary/20 border-t-primary rounded-full animate-spin" />
          <p className="text-[10px] font-mono text-neutral-500 uppercase tracking-[0.4em] animate-pulse">
            Booting_Orion_OS...
          </p>
        </div>
      </div>
    );
  }

  return (
    <OrionShell>
      <NavigationEngine />
    </OrionShell>
  );
}
