import mqtt, { MqttClient } from 'mqtt';
import { Server } from 'socket.io';

export class BackendMqttManager {
  private static instance: BackendMqttManager;
  private client: MqttClient | null = null;
  private io: Server | null = null;
  private connected = false;

  private constructor() {}

  public static getInstance(): BackendMqttManager {
    if (!BackendMqttManager.instance) {
      BackendMqttManager.instance = new BackendMqttManager();
    }
    return BackendMqttManager.instance;
  }

  public init(io: Server) {
    this.io = io;
    this.connect();
  }

  private connect() {
    const brokerUrl = process.env.MQTT_URL || 'wss://broker.emqx.io:8084/mqtt';
    console.log(`[BACKEND_MQTT] Connecting to ${brokerUrl}...`);

    try {
      this.client = mqtt.connect(brokerUrl, {
        clientId: `orion_backend_${Math.random().toString(16).slice(2, 8)}`,
        clean: true,
        connectTimeout: 15000,
        keepalive: 60,
        reconnectPeriod: 5000,
        protocolVersion: 5,
        rejectUnauthorized: false,
        path: '/mqtt'
      });

      this.client.on('connect', () => {
        console.log('[BACKEND_MQTT] Connected to broker');
        this.connected = true;
        this.broadcastStatus();
        this.client?.subscribe(['orion/telemetry/#', 'orion/status/#', 'orion/commands/#']);
      });

      this.client.on('message', (topic, payload) => {
        this.io?.emit('mqtt:message', { topic, payload: payload.toString() });
      });

      this.client.on('close', () => {
        if (this.connected) {
          console.log('[BACKEND_MQTT] Connection closed');
          this.connected = false;
          this.broadcastStatus();
        }
      });

      this.client.on('error', (err) => {
        console.error(`[BACKEND_MQTT] Error: ${err.message}`);
      });

    } catch (error) {
      console.error('[BACKEND_MQTT] Initialization failed:', error);
    }
  }

  private broadcastStatus() {
    this.io?.emit('mqtt:status', { 
      connected: this.connected, 
      timestamp: Date.now() 
    });
  }

  public publish(topic: string, message: string) {
    if (this.connected && this.client) {
      this.client.publish(topic, message);
    }
  }
}

export const backendMqttManager = BackendMqttManager.getInstance();
