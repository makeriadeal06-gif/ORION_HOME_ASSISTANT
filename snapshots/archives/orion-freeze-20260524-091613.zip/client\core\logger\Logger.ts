import { LogLevel, LogEntry } from './LogLevels';

class Logger {
  private static instance: Logger;
  private currentLevel: LogLevel = LogLevel.INFO;
  private lastLogs: Map<string, { message: string, count: number, timestamp: number }> = new Map();
  private readonly THROTTLE_THRESHOLD = 5000; // 5 seconds for duplicate suppression

  private constructor() {
    // In development we might want DEBUG
    if (process.env.NODE_ENV === 'development') {
      this.currentLevel = LogLevel.DEBUG;
    }
  }

  public static getInstance(): Logger {
    if (!Logger.instance) {
      Logger.instance = new Logger();
    }
    return Logger.instance;
  }

  public setLevel(level: LogLevel) {
    this.currentLevel = level;
  }

  private shouldLog(level: LogLevel, category: string, message: string): boolean {
    if (level < this.currentLevel) return false;

    // Duplicate suppression
    const key = `${category}:${message}`;
    const last = this.lastLogs.get(key);
    const now = Date.now();

    if (last && now - last.timestamp < this.THROTTLE_THRESHOLD) {
      last.count++;
      return false;
    }

    if (last && last.count > 0) {
      console.log(`[${category}] (Suppressed ${last.count} duplicate messages)`);
    }

    this.lastLogs.set(key, { message, count: 0, timestamp: now });
    return true;
  }

  private formatMessage(level: LogLevel, category: string, message: string): string {
    const levelStr = LogLevel[level];
    return `[${category}] ${message}`;
  }

  public trace(category: string, message: string, data?: any) {
    if (this.shouldLog(LogLevel.TRACE, category, message)) {
      console.trace(this.formatMessage(LogLevel.TRACE, category, message), data || '');
    }
  }

  public debug(category: string, message: string, data?: any) {
    if (this.shouldLog(LogLevel.DEBUG, category, message)) {
      console.debug(this.formatMessage(LogLevel.DEBUG, category, message), data || '');
    }
  }

  public info(category: string, message: string, data?: any) {
    if (this.shouldLog(LogLevel.INFO, category, message)) {
      console.info(this.formatMessage(LogLevel.INFO, category, message), data || '');
    }
  }

  public warn(category: string, message: string, data?: any) {
    if (this.shouldLog(LogLevel.WARN, category, message)) {
      console.warn(this.formatMessage(LogLevel.WARN, category, message), data || '');
    }
  }

  public error(category: string, message: string, data?: any) {
    if (this.shouldLog(LogLevel.ERROR, category, message)) {
      console.error(this.formatMessage(LogLevel.ERROR, category, message), data || '');
    }
  }
}

export const logger = Logger.getInstance();
