import { create } from 'zustand';
import { OrionDevice, EcosystemMap } from '../types';
import { EcosystemMapper } from '../ecosystem/EcosystemMapper';

interface DeviceState {
  devices: Record<string, OrionDevice>;
  ecosystem: EcosystemMap;
  lastSync: number;
}

interface DeviceActions {
  setDevices: (devices: OrionDevice[]) => void;
  updateDevice: (id: string, update: Partial<OrionDevice>) => void;
  syncEcosystem: () => void;
}

export const useDeviceStore = create<DeviceState & DeviceActions>((set, get) => ({
  devices: {},
  ecosystem: { rooms: {}, unassigned: [] },
  lastSync: 0,

  setDevices: (devicesList) => {
    const devices: Record<string, OrionDevice> = {};
    devicesList.forEach(d => devices[d.id] = d);
    set({ devices, lastSync: Date.now() });
    get().syncEcosystem();
  },

  updateDevice: (id, update) => {
    set((state) => {
      const device = state.devices[id];
      if (!device) return state;
      return {
        devices: { ...state.devices, [id]: { ...device, ...update } }
      };
    });
    get().syncEcosystem();
  },

  syncEcosystem: () => {
    const ecosystem = EcosystemMapper.map();
    set({ ecosystem });
  }
}));
